import React from 'react';

export function Welcome() {
    return(
        <div id="intro">
            <h1>Åben dit køleskab,<br/>
                som var du derhjemme</h1>
            <p>Det her er dit online køleskab, <br/>så du
               altid vil kunne se hvad du har i det,<br/>
               selvom du er på farten.</p>
        </div>
    )
}