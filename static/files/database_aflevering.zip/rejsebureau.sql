-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Vært: 127.0.0.1
-- Genereringstid: 11. 03 2020 kl. 08:25:27
-- Serverversion: 10.4.11-MariaDB
-- PHP-version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rejsebureau`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `byer`
--

CREATE TABLE `byer` (
  `postnr` int(4) NOT NULL,
  `bynavn` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `destinationer`
--

CREATE TABLE `destinationer` (
  `lufthavn` varchar(30) NOT NULL,
  `byer` varchar(30) DEFAULT NULL,
  `lande` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `kunde`
--

CREATE TABLE `kunde` (
  `kundenr` int(11) NOT NULL,
  `fornavn` varchar(20) DEFAULT NULL,
  `efternavn` varchar(20) DEFAULT NULL,
  `adresse` varchar(40) DEFAULT NULL,
  `postnr` int(4) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `rejseordrer`
--

CREATE TABLE `rejseordrer` (
  `ordrenr` int(11) NOT NULL,
  `bestillingsnummer` int(100) DEFAULT NULL,
  `rejsenr` int(100) DEFAULT NULL,
  `bestillingsdato` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `rejser`
--

CREATE TABLE `rejser` (
  `rejsenr` int(11) NOT NULL,
  `destination` varchar(30) DEFAULT NULL,
  `afrejsedato` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `byer`
--
ALTER TABLE `byer`
  ADD PRIMARY KEY (`postnr`);

--
-- Indeks for tabel `destinationer`
--
ALTER TABLE `destinationer`
  ADD PRIMARY KEY (`lufthavn`);

--
-- Indeks for tabel `kunde`
--
ALTER TABLE `kunde`
  ADD PRIMARY KEY (`kundenr`),
  ADD KEY `postnr` (`postnr`);

--
-- Indeks for tabel `rejseordrer`
--
ALTER TABLE `rejseordrer`
  ADD PRIMARY KEY (`ordrenr`),
  ADD KEY `rejsenr` (`rejsenr`),
  ADD KEY `bestillingsnummer` (`bestillingsnummer`);

--
-- Indeks for tabel `rejser`
--
ALTER TABLE `rejser`
  ADD PRIMARY KEY (`rejsenr`),
  ADD KEY `destination` (`destination`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `kunde`
--
ALTER TABLE `kunde`
  MODIFY `kundenr` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tilføj AUTO_INCREMENT i tabel `rejseordrer`
--
ALTER TABLE `rejseordrer`
  MODIFY `ordrenr` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tilføj AUTO_INCREMENT i tabel `rejser`
--
ALTER TABLE `rejser`
  MODIFY `rejsenr` int(11) NOT NULL AUTO_INCREMENT;

--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `kunde`
--
ALTER TABLE `kunde`
  ADD CONSTRAINT `kunde_ibfk_1` FOREIGN KEY (`postnr`) REFERENCES `byer` (`postnr`);

--
-- Begrænsninger for tabel `rejseordrer`
--
ALTER TABLE `rejseordrer`
  ADD CONSTRAINT `rejseordrer_ibfk_1` FOREIGN KEY (`rejsenr`) REFERENCES `rejser` (`rejsenr`),
  ADD CONSTRAINT `rejseordrer_ibfk_2` FOREIGN KEY (`bestillingsnummer`) REFERENCES `kunde` (`kundenr`);

--
-- Begrænsninger for tabel `rejser`
--
ALTER TABLE `rejser`
  ADD CONSTRAINT `rejser_ibfk_1` FOREIGN KEY (`destination`) REFERENCES `destinationer` (`lufthavn`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
